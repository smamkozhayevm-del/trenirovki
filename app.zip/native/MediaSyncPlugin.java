package kz.subtitlereader.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.KeyEvent;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Lets the subtitle reader follow and control the video app (Crunchyroll and others).
 *
 * state()   - what is playing in other apps: package, playing, position (ms), title.
 *             Needs "notification access" for this app; without it, access=false.
 * control() - play / pause / seek the video. Uses the video's media session when
 *             access is granted, otherwise sends the system play/pause key
 *             (like the button on headphones).
 * openAccessSettings() - opens Android's notification access screen.
 */
@CapacitorPlugin(name = "MediaSync")
public class MediaSyncPlugin extends Plugin {

    private List<MediaController> others() {
        MediaSessionManager m = (MediaSessionManager) getContext().getSystemService(Context.MEDIA_SESSION_SERVICE);
        List<MediaController> all = m.getActiveSessions(new ComponentName(getContext(), MediaListener.class));
        List<MediaController> out = new ArrayList<>();
        String me = getContext().getPackageName();
        for (MediaController c : all) {
            if (!me.equals(c.getPackageName())) out.add(c);
        }
        return out;
    }

    private static boolean isPlaying(MediaController c) {
        PlaybackState st = c.getPlaybackState();
        return st != null && (st.getState() == PlaybackState.STATE_PLAYING || st.getState() == PlaybackState.STATE_BUFFERING);
    }

    /** the session for this package if given, else the one that is playing, else the most recent */
    private MediaController pick(String pkg) {
        List<MediaController> list = others();
        if (pkg != null) {
            for (MediaController c : list) if (pkg.equals(c.getPackageName())) return c;
        }
        for (MediaController c : list) if (isPlaying(c)) return c;
        return list.isEmpty() ? null : list.get(0);
    }

    private static long positionNow(PlaybackState st) {
        long pos = st.getPosition();
        long at = st.getLastPositionUpdateTime();
        if (st.getState() == PlaybackState.STATE_PLAYING && at > 0) {
            pos += (long) ((SystemClock.elapsedRealtime() - at) * st.getPlaybackSpeed());
        }
        return Math.max(0, pos);
    }

    @PluginMethod
    public void state(PluginCall call) {
        JSObject r = new JSObject();
        JSArray sessions = new JSArray();
        try {
            for (MediaController c : others()) {
                JSObject o = new JSObject();
                o.put("package", c.getPackageName());
                PlaybackState st = c.getPlaybackState();
                if (st != null) {
                    o.put("state", st.getState());
                    o.put("playing", isPlaying(c));
                    o.put("position", positionNow(st));
                    o.put("speed", (double) st.getPlaybackSpeed());
                }
                MediaMetadata md = c.getMetadata();
                if (md != null) {
                    String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                    if (title != null) o.put("title", title);
                    o.put("duration", md.getLong(MediaMetadata.METADATA_KEY_DURATION));
                }
                sessions.put(o);
            }
            r.put("access", true);
        } catch (SecurityException e) {
            r.put("access", false);
        }
        r.put("sessions", sessions);
        call.resolve(r);
    }

    @PluginMethod
    public void control(PluginCall call) {
        String action = call.getString("action", "pause");
        String pkg = call.getString("package", null);
        String via = "none";
        try {
            MediaController c = pick(pkg);
            if (c != null) {
                MediaController.TransportControls t = c.getTransportControls();
                if ("play".equals(action)) t.play();
                else if ("seek".equals(action)) {
                    Object p = call.getData().opt("position");
                    t.seekTo(Math.max(0L, p instanceof Number ? ((Number) p).longValue() : 0L));
                }
                else t.pause();
                via = "session";
            }
        } catch (SecurityException e) {
            // no notification access: fall back to the media key below
        }
        if ("none".equals(via) && !"seek".equals(action)) {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            int code = "play".equals(action) ? KeyEvent.KEYCODE_MEDIA_PLAY : KeyEvent.KEYCODE_MEDIA_PAUSE;
            long now = SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0));
            am.dispatchMediaKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0));
            via = "key";
        }
        JSObject r = new JSObject();
        r.put("via", via);
        call.resolve(r);
    }

    @PluginMethod
    public void openAccessSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void openAppSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getContext().getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }
}
